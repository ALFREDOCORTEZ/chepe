import turtle
tina = turtle.Turtle()
tina.shape('turtle')

tina.penup()
tina.forward(20)
tina.write("Why, hello there!")
tina.backward(20)